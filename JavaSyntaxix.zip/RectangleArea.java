import java.util.Scanner;

public class RectangleArea {
public static void main(String[] args) {
 Scanner inputScan=new Scanner(System.in);
 Integer Anumber=inputScan.nextInt();
 Integer Bnumber=inputScan.nextInt();

 System.out.println(Anumber*Bnumber);
}
}
